window.linkOpener = function ($) {
    return function (event, id, url, target) {
        event = event || window.event;
        if (url.search('preview') === -1 && $(event.target).closest('.image.component').hasClass('id' + id)) {
            event.stopPropagation();
            window.open(url, target);
        } else {
            $(event.target).attr('href', url);
        }
    };
}(oneJQuery);
oneJQuery(function ($) {
    var menuList = $('.menu');
    var moreWidth;
    menuList.each(function (indx, menu) {
        var $menu = $(menu), menuWidth = $menu.width(), moreEnabled = $menu.find('.moreEnabled'), removeIndx = null;
        if (moreEnabled.length) {
            var moreParent = moreEnabled.parent();
            moreWidth = moreWidth || moreEnabled.removeClass('displayNone').closest('li').width();
            moreParent.find('li').remove();
            var tmp = moreEnabled.closest('li');
            tmp.detach();
            var items = $menu.find('ul:eq(0)>li');
            [].slice.call(items).some(function (item, i) {
                item = $(item);
                item.find('.menuitem').removeClass('displayNone');
                menuWidth -= item.width();
                if (menuWidth - moreWidth < 0) {
                    removeIndx = i;
                    return true;
                }
            });
            if (items.length - 1 === removeIndx && menuWidth > 0) {
                removeIndx = null;
            }
            if (removeIndx !== null) {
                if (removeIndx === 0) {
                    moreEnabled.closest('li').find('.divider').remove();
                }
                var list = $menu.find('ul:eq(0)>li');
                for (var i = removeIndx; i < list.length; i++) {
                    var nodeTobeReplaced = $(list[i]);
                    nodeTobeReplaced.detach();
                    nodeTobeReplaced.find('.divider').remove();
                    tmp.find('ul:eq(0)').append(nodeTobeReplaced);
                }
                $menu.find('ul:eq(0)').append(tmp);
                $menu.find('ul:eq(0) .menuitem').removeClass('displayNone');
            }
        }
    });
    $('.menu li > div > .menucascadeanchor, .menu li > div.menucascadeanchor').each(function () {
        var subMenuEl = $(this), alreadyDone = subMenuEl.closest('.bodysubmenu')[0], li = subMenuEl.closest('li');
        if (alreadyDone || this.childElementCount === 0) {
            return;
        }
        var wrapper = $(document.createElement('div')), isHorizontalMenu = !!subMenuEl.closest('.menuhorizontal').length;
        wrapper.addClass('bodysubmenu');
        if (isHorizontalMenu) {
            wrapper.addClass('menuhorizontal');
        } else {
            wrapper.addClass('menuvertical');
        }
        if (subMenuEl.closest('.menuhorizontalleft').length) {
            wrapper.addClass('menuhorizontalleft');
        } else if (subMenuEl.closest('.menuhorizontalcenter').length) {
            wrapper.addClass('menuhorizontalcenter');
        } else if (subMenuEl.closest('.menuhorizontalright').length) {
            wrapper.addClass('menuhorizontalright');
        } else if (subMenuEl.closest('.menuhorizontalfit').length) {
            wrapper.addClass('menuhorizontalfit');
        }
        subMenuEl.detach();
        wrapper.append(subMenuEl);
        $(document.body).append(wrapper);
        li.mouseenter(function () {
            var dividerEl = $('.divider', li), dividerWidth = 0;
            if (dividerEl) {
                dividerWidth = dividerEl.innerWidth();
            }
            li.addClass('hover');
            wrapper.css('display', 'block');
            var offset = li.offset();
            if (isHorizontalMenu) {
                wrapper.css('top', Math.floor(offset.top) + li.outerHeight());
                wrapper.css('left', offset.left + dividerWidth);
            } else {
                wrapper.css('top', Math.floor(offset.top));
                wrapper.css('left', offset.left + li.outerWidth() + dividerWidth);
            }
        });
        li.mouseleave(function (e) {
            var inSubMenu = $.contains(wrapper[0], e.relatedTarget);
            if (!inSubMenu) {
                li.removeClass('hover');
                wrapper.css('display', 'none');
            }
        });
        wrapper.mouseout(function (e) {
            var inParentItem = $.contains(li, e.relatedTarget), inSubMenu = $.contains(wrapper[0], e.relatedTarget);
            if (!inParentItem && !inSubMenu) {
                li.removeClass('hover');
                wrapper.css('display', 'none');
            }
        });
        if (('ontouchstart' in window || 'onmspointerdown' in window) && !navigator.userAgent.toLowerCase().match(/windows phone os 7/i)) {
            var menuItems = $.merge(li.find('a[class*="expandable"]'), $('.bodysubmenu a[class*="expandable"]'));
            if ('onmspointerdown' in window) {
                menuItems.each(function () {
                    $(this).attr('aria-haspopup', true);
                });
            } else {
                var lastClicked = null;
                menuItems.each(function () {
                    var self = oneJQuery(this);
                    self.on('click', function (e) {
                        var item = oneJQuery(this);
                        var isCurrentPreviouslyClicked = item.is(lastClicked), isCurrentAncestorOfPrevious = oneJQuery.contains(e.target.parentNode, lastClicked);
                        var shouldPreventDefault = true;
                        if (lastClicked === null) {
                            shouldPreventDefault = true;
                        } else if (isCurrentPreviouslyClicked) {
                            shouldPreventDefault = false;
                        } else if (isCurrentAncestorOfPrevious) {
                            shouldPreventDefault = false;
                        }
                        if (shouldPreventDefault) {
                            e.preventDefault();
                        }
                        lastClicked = e.target;
                    });
                });
                if (navigator.userAgent.toLowerCase().match(/mac/i)) {
                    li.mouseenter(function (e) {
                        if (!lastClicked) {
                            lastClicked = e.target;
                        }
                    });
                    $(document).on('touchstart', function (e) {
                        if (!$(e.target).hasClass('menuitem')) {
                            li.trigger('mouseout', e);
                            lastClicked = null;
                        }
                    });
                }
            }
        }
    });
});
oneJQuery(document).ready(function () {
    oneJQuery('ul.shareButtonCntnr').delegate('a', 'click', function (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        window.open(oneJQuery(this).attr('href') + encodeURIComponent(window.location.href));
    });
});
(function () {
    function run() {
        var g = function (id) {
                return document.getElementById(id);
            }, ttl = g('mmt'), btn = g('mmb'), menu = g('mm'), body = document.getElementsByTagName('body')[0], on = false, height;
        if (!btn || !menu || !body) {
            return;
        }
        function onclick() {
            on = !on;
            if (on) {
                btn.className = 'on';
                menu.className = 'on';
                height = Math.max(window.innerHeight || document.documentElement.clientHeight, body.offsetHeight, menu.offsetHeight);
                menu.style.height = height + 'px';
            } else {
                btn.className = 'off';
                menu.className = 'off';
            }
        }
        ttl.onclick = onclick;
        btn.onclick = onclick;
        menu.onclick = function (e) {
            var target, parent;
            target = e ? e.target : window.event.srcElement;
            target = target.nodeType === 3 ? target.parentNode : target;
            if (target.tagName === 'DIV' && target.id !== 'mm') {
                parent = target.parentNode;
                parent.className = parent.className ? '' : 'expanded';
            }
        };
    }
    var readyTimer = setInterval(function () {
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            run();
            clearInterval(readyTimer);
        }
    }, 10);
}());
(function () {
    function run() {
        var segments = [], innerBody = document.querySelector('.template'), innerParent = innerBody.parentNode, leaves = document.querySelectorAll('.mobile-leaf'), src, newBase, newLeaf, i, node, base, len, leaf, seg, weight, id;
        for (i = 0, len = leaves.length; i < len; i += 1) {
            leaf = leaves[i];
            weight = (leaf.getAttribute('data-weight') || 0) - 0;
            if (weight) {
                node = leaf.parentNode;
                base = null;
                id = leaf.getAttribute('data-id');
                while (node.tagName !== 'BODY' && !base) {
                    base = /mobile-base/.test(node.className) ? node : base;
                    id = id || node.getAttribute('data-id');
                    node = node.parentNode;
                }
                segments.push({
                    id: id,
                    leaf: leaf,
                    base: base,
                    weight: weight
                });
            }
        }
        segments.sort(function (a, b) {
            return a.weight - b.weight;
        });
        for (i = 0, len = segments.length; i < len; i += 1) {
            seg = segments[i];
            newLeaf = document.createElement('DIV');
            newLeaf.setAttribute('class', seg.leaf.className);
            if (seg.id) {
                newLeaf.setAttribute('data-id', seg.id);
            }
            newLeaf.setAttribute('data-weight', seg.weight);
            src = newLeaf;
            if (seg.base) {
                newBase = document.createElement('DIV');
                newBase.setAttribute('class', seg.base.className + ' mobile-base-moved');
                newBase.setAttribute('style', seg.base.getAttribute('style'));
                newBase.appendChild(newLeaf);
                src = newBase;
            }
            seg.leaf.className += ' mobile-hide';
            src.className += ' mobile-show';
            if (seg.weight < 0) {
                innerParent.insertBefore(src, innerBody);
            } else {
                innerParent.appendChild(src);
            }
            seg.newLeaf = newLeaf;
        }
        function isMobile() {
            var width = window.innerWidth || document.documentElement.clientWidth;
            return width <= 650;
        }
        function move() {
            var mobile = isMobile();
            for (i = 0, len = segments.length; i < len; i += 1) {
                seg = segments[i];
                if (mobile) {
                    if (seg.newLeaf && seg.leaf && seg.leaf.children.length) {
                        addChildren(seg.newLeaf, seg.leaf.children);
                    }
                } else {
                    if (seg.leaf && seg.newLeaf && seg.newLeaf.children.length) {
                        addChildren(seg.leaf, seg.newLeaf.children);
                    }
                }
            }
        }
        function addChildren(node, children) {
            var child = children[0];
            while (child) {
                node.appendChild(child);
                child = children[0];
            }
        }
        move();
        var timer;
        function timedMove() {
            clearTimeout(timer);
            timer = setTimeout(move, 200);
        }
        if (window.addEventListener) {
            window.addEventListener('resize', timedMove);
        } else if (window.attachEvent) {
            window.attachEvent('onresize', timedMove);
        }
    }
    var readyTimer = setInterval(function () {
        if (document.readyState === 'complete') {
            run();
            clearInterval(readyTimer);
        }
    }, 10);
    window.runMobileSort = run;
}());