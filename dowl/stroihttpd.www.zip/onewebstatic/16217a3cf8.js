oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-AAC5707F-CF12-4847-BD77-98F8492197AF .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-C0BC31D2-FB9C-4984-9295-D46949D06968 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-5ACD47A0-75FB-4118-AF8C-F1178A99E7F1 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-A7F3A0FA-CBC0-4EAF-B69C-235426B3E572 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-0BF5F82C-66C9-4887-A870-6E406B8C0EC1 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-E1C477CC-FF0E-4E5D-AC3A-899ED41442E1 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-7694885C-579E-4428-9080-BC54F72BAA81 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-70CF8A63-6B67-4E57-AD7D-DC23AF3E473A .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-FBCDEE00-70A7-4E11-AFED-6E15ACB38EA8 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-ED4EA963-3A10-4C31-B6E8-A7EA2DEEBCE7 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});