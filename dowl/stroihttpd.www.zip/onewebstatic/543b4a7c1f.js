oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-77AAAC0C-34BC-4A27-A4DF-00C20E6F297D .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-F170FEDA-B976-4C78-BBAF-17C7FCDCCC6C .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});
oneJQuery(function ($) {
    var json = {
        'slideSpeed': 1024,
        'singleItem': true,
        'itemsScaleUp': true,
        'autoPlay': false,
        'navigation': true,
        'navigationText': [
            '',
            ''
        ],
        'transitionStyle': false
    };
    json.afterAction = function () {
        var that = this;
        clearTimeout(this.preemptFirstSlideTimo);
        if (!this.options.transitionStyle) {
            if (this.currentItem === this.itemsAmount - 1) {
                if (this.prevItem !== 0) {
                    setTimeout(function () {
                        that.jumpTo(0);
                    }, 1024);
                } else {
                    that.jumpTo(that.currentItem);
                    setTimeout(function () {
                        that.goTo(that.currentItem - 1);
                    }, 10);
                }
            } else if (this.currentItem === 0 && this.options.autoPlay) {
                this.preemptFirstSlideTimo = setTimeout(function () {
                    that.goTo(1);
                }, this.options.autoPlay - 1024);
            }
        }
        oneJQuery('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773 .slider-caption').each(function () {
            var el = oneJQuery(this);
            el.width(el.parent().width() - 10);
        });
        oneJQuery('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773 .slide-cntnr.middle p.slider-caption').each(function () {
            var el = oneJQuery(this);
            el.height(el.find('span').height());
        });
    };
    var $slidejs = $('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773');
    if ($slidejs.children().length) {
        var carousel = $slidejs.owlCarousel(json);
        carousel.data('owlCarousel').updateVars();
        var resetHeight = function () {
            if (window.innerWidth < 650) {
                var ratio = 0.6382978723404256;
                if ($('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773').parents('.textblock').length) {
                    ratio = ratio / 2;
                }
                $('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773 .slider-item').height((window.innerWidth - 40) * ratio);
                $('#slidesjs-3C199B8C-DFC2-40BD-8810-D8FF3DDC5773 .slider-caption').parent().height((window.innerWidth - 40) * ratio);
            }
        };
        $(window).resize(resetHeight);
        resetHeight();
    }
});